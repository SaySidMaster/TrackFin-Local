import { useState } from 'react'
import { Link, useLocation, useNavigate } from 'react-router-dom'
import trackfinLogo from '../assets/trackfin.png'
import logoutIcon from '../assets/icons/logout.svg'
import profileIcon from '../assets/icons/profile.svg'
import { useDialog } from "../context/DialogContext";
import { logout } from "../services/AuthServices";
import { changeOwnPassword } from "../services/UserServices";

const SideNavBar = () => {
  const navigate = useNavigate();
  const [isOpen, setIsOpen] = useState(true)
  const location = useLocation() // 👈 récupère la route actuelle
  const user = JSON.parse(localStorage.getItem("user"));

  const menuItems = [
    { id: 1, page: '/dashboard', label: 'Tableau de bord', icon: 'dashboard.svg' },
    { id: 2, page: '/transactions', label: 'Transactions', icon: 'transactions.svg' },
    { id: 3, page: '/debts', label: 'Dettes & Créances', icon: 'dettes.svg' },
    { id: 4, page: '/budgets', label: 'Budgets', icon: 'budgets.svg' },
    { id: 5, page: '/contacts', label: 'Clients & Fournisseurs', icon: 'contacts.svg' },
    { id: 6, page: '/parametres', label: 'Paramètres', icon: 'parametres.svg' },
  ]

  const getIconStyle = (isActive) => ({
    width: '18px',
    height: '18px',
    objectFit: 'contain',
    filter: isActive
      ? 'invert(79%) sepia(50%) saturate(400%) hue-rotate(90deg) brightness(1)'
      : '',
  })

  const getLabelStyle = (isActive) => ({
    color: isActive ? 'white' : 'black',
    fontSize: '14px',
    fontWeight: isActive ? 'bold' : 'normal',
  })


  // Changer son propre mot de passe (depuis n'importe quelle page)
  const handleChangeOwnPasswordDialog = () => {
    openDialog({
      title: "Changer mon mot de passe",
      fields: [
        { key: "password", type: "password", label: "Nouveau mot de passe", required: true },
        { key: "password_confirmation", type: "password", label: "Confirmer mot de passe", required: true },
      ],
      onSubmit: async (values) => {
        if (values.password !== values.password_confirmation) {
          alert("Les mots de passe ne correspondent pas.");
          return;
        }
        try {
          const result = await changeOwnPassword(values);
          alert(result.message ?? "Mot de passe changé avec succès.");
        } catch (error) {
          alert(error.message);
        }
      },
    });
  };

  const { openDialog } = useDialog();

  const handleUserDialog = async () => {
    // L'utilisateur connecté est par défaut et ne peut pas être modifiées

    openDialog({
      title: "Détails du profil — " + user.name,
      initialValues: {
        name: user.name,
        email: user.email,
        role: user.role,
      },
      fields: [
        { key: "name", type: "text", label: "Nom", required: true },
        { key: "email", type: "email", label: "Email", required: true, disabled: true },
        {
          key: "role", type: "select", label: "Rôle", required: true, disabled: true,
          options: [{ value: "admin", label: "Administrateur" }, { value: "accountant", label: "Comptable" }, { value: "cashier", label: "Caissier" }, { value: "user", label: "Utilisateur" }]
        },
      ],
      onPasswordChange: handleChangeOwnPasswordDialog,
      onLogout: handleLogout,
      onSubmit: async (values) => {
        try {
          await updateUser(profile.id, {
            name: values.name,
            email: values.email,
            role: values.role,
          });
          await refreshProfiles();
        } catch (error) {
          alert(error.message);
        }
      },
    });
  };


  const handleLogout = async (e) => {
    try {
      await logout();
    } catch (error) {
      console.error("Erreur lors du logout:", error);
    } finally {
      // Redirection systématique vers login après une tentative de logout
      navigate("/login");
    }
  };

  return (
    <nav className='SideNavBar'>
      <div className='navTop'>
        <div className='logo-container'>
          <img src={trackfinLogo} style={{ width: '40px', height: '40px', objectFit: 'contain' }} alt="" />
          <h3 className='AppTitle'>TrackFin</h3>
        </div>

        <div style={{ width: '100%', height: '1px', backgroundColor: '#71717170' }}></div>

        <div className='menuList' style={{ width: '100%' }}>
          {menuItems.map((item) => {
            const iconSrc = new URL(`../assets/icons/${item.icon}`, import.meta.url).href
            const isActive = location.pathname.includes(item.page) // 👈 compare avec la route actuelle

            return (
              <Link
                to={item.page}
                key={item.id}
                className={`menu-item${isActive ? ' menu-item--active' : ''}`}
                style={{ backgroundColor: isActive ? '#081226' : 'transparent' }}
              >
                <img
                  src={iconSrc}
                  alt={item.label}
                  style={getIconStyle(isActive)}
                />
                {isOpen && <span style={getLabelStyle(isActive)}>{item.label}</span>}
              </Link>
            )
          })}
          <div className="mobile-only" style={{ display: "flex", gap: 0 }}>
            <button
              onClick={handleUserDialog}
              className="menu-item"
              style={{ background: "transparent", border: "none" }}
            >
              <img src={profileIcon} alt="Profil" style={getIconStyle(false)} />
              <span style={getLabelStyle(false)}>Profil</span>
            </button>
          </div>
        </div>
      </div>
      <div className='profileButton'>
        <button onClick={handleUserDialog} style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'start', border: 'none', background: 'transparent' }}>
          <h3 style={{ margin: '0' }}>{user?.name || "Utilisateur"}</h3>
          <p style={{ margin: '0', textTransform: 'uppercase' }}>{user?.role || "Utilisateur"}</p>
        </button>
      </div>
    </nav>
  )
}

export default SideNavBar
