import Banner from "../components/Banner";

function Parametres() {
  return (
    <div className="pageBloc">
      <Banner title="Paramètres" />

      {/* Contenu de la page Paramètres */}
      {/* Categories and général */}

      {/* Profils bloc */}
      <div className="ScrollableDiv" style={{
        height: "75vh",
        display: "flex",
        flexWrap: "wrap",
        gap: "12px",
        padding: "20px",
        border: "1px solid #0000001a",
        borderRadius: "20px",
      }}>


        {[...Array(15)].map((_, i) => (
          <ContactBox
            key={i}
            id={i}
            type={i % 2 === 0 ? "Client" : "Fournisseur"}
            name={i % 2 === 0 ? "Jean Dupont" : "Marie Martin"}
            number={i % 2 === 0 ? "01 23 45 67 89" : "02 34 56 78 90"}
            email={i % 2 === 0 ? "jean.dupont@email.com" : "marie.martin@email.com"}
          />
        ))}
      </div>
    </div>
  );
}

export default Parametres;