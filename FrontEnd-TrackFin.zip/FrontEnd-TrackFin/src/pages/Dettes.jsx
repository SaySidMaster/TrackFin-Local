import Banner from "../components/Banner";
import CallToAction1 from "../components/CallToAction1";
import addIcon from "../assets/icons/add.svg";

function Dettes() {
  return (
    <div className="pageBloc">
      <Banner title="Dettes" callToAction={<CallToAction1 title="Nouvelle dette" iconSrc={addIcon} action={() => {}} />}/>
    </div>
  );
}

export default Dettes;