import Banner from "../components/Banner";
import CallToAction1 from "../components/CallToAction1";
import addIcon from "../assets/icons/add.svg";

function Transactions() {
  return (
    <div className="pageBloc">
      <Banner title="Transactions" callToAction={<CallToAction1 title="Nouvelle transaction" iconSrc={addIcon} action={() => {}} />}/>
    </div>
  );
}

export default Transactions;